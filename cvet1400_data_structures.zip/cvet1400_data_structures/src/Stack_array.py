"""
-------------------------------------------------------
Array version of the Stack ADT.
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-06"
-------------------------------------------------------
"""
from copy import deepcopy


class Stack:

    def __init__(self):
        """
        -------------------------------------------------------
        Initializes an is_empty stack. Data is stored in a Python list.
        Use: s = Stack()
        -------------------------------------------------------
        Returns:
            a new Stack object (Stack)
        -------------------------------------------------------
        """
        self._values = []

    def is_empty(self):
        """
        -------------------------------------------------------
        Determines if the stack is empty.
        Use: b = s.is_empty()
        -------------------------------------------------------
        Returns:
            True if the stack is empty, False otherwise
        -------------------------------------------------------
        """

        return len(self._values) <= 0

    def push(self, value):
        """
        -------------------------------------------------------
        Pushes a copy of value onto the top of the stack.
        Use: s.push(value)
        -------------------------------------------------------
        Parameters:
            value - a data element (?)
        Returns:
            None
        -------------------------------------------------------
        """

        self._values.append(deepcopy(value))
        return None

    def pop(self):
        """
        -------------------------------------------------------
        Pops and returns the top of stack. The value is removed
        from the stack. Attempting to pop from an empty stack
        throws an exception.
        Use: value = s.pop()
        -------------------------------------------------------
        Returns:
            value - the value at the top of the stack (?)
        -------------------------------------------------------
        """
        assert len(self._values) > 0, "Cannot pop from an empty stack"

        value = self._values.pop(-1)
        return value

    def peek(self):
        """
        -------------------------------------------------------
        Returns a copy of the value at the top of the stack.
        Attempting to peek at an empty stack throws an exception.
        Use: value = s.peek()
        -------------------------------------------------------
        Returns:
            value - a copy of the value at the top of the stack (?)
        -------------------------------------------------------
        """
        assert len(self._values) > 0, "Cannot peek at an empty stack"

        value = deepcopy(self._values[-1])
        return value

    def reverse(self):
        """
        -------------------------------------------------------
        Reverses the contents of the source stack.
        Use: source.reverse()
        -------------------------------------------------------
        Returns:
            None
        -------------------------------------------------------
        """

        temp1 = Stack()
        temp2 = Stack()

        if len(self._values) > 0:
            while len(self._values) > 0:
                temp1._values.append(self._values.pop(-1))
            while len(temp1._values) > 0:
                temp2._values.append(temp1._values.pop(-1))
            while len(temp2._values) > 0:
                self._values.append(temp2._values.pop(-1))

        return None

        # or
        # temp = []
        #
        # while len(self._values) > 0:
        #     temp.append(self._values.pop())
        #
        # while len(temp) > 0:
        #     self._values.append(temp.pop(0))
        # return

    def combine(self, source1, source2):
        """
        -------------------------------------------------------
        Combines two source stacks into the current target stack.
        When finished, the contents of source1 and source2 are interlaced
        into target and source1 and source2 are empty.
        Use: target.combine(source1, source2)
        -------------------------------------------------------
        Parameters:
        source1 - an array-based stack (Stack)
        source2 - an array-based stack (Stack)
        Returns:
        None
        -------------------------------------------------------
        """
        while len(source1._values) > 0 or len(source2._values) > 0:
            if len(source1._values) > 0:
                val1 = source1._values.pop()
                self._values.append(val1)
            if len(source2._values) > 0:
                val2 = source2._values.pop()
                self._values.append(val2)
        return None

    def split_alt(self):
        """
        -------------------------------------------------------
        Splits source stack into two target Stacks.
        When finished, the contents of source are empty. Target1
        and target2 are interlaced.
        Use: target1, target2 = s.split_alt()
        -------------------------------------------------------
        Parameters:
        None
        Returns:
        target1 - evenly indexed Stack (Stack)
        target2 - oddly indexed Stack (Stack)
        -------------------------------------------------------
        """
        target1 = Stack()
        target2 = Stack()

        alt = True
        while len(self._values) > 0:
            if alt:
                value1 = self._values.pop(-1)
                target1._values.append(value1)
                alt = False
            else:
                value2 = self._values.pop(-1)
                target2._values.append(value2)
                alt = True
        return target1, target2

    def __iter__(self):
        """
        FOR TESTING ONLY
        -------------------------------------------------------
        Generates a Python iterator. Iterates through the stack
        from top to bottom.
        Use: for v in s:
        -------------------------------------------------------
        Returns:
            value - the next value in the stack (?)
        -------------------------------------------------------
        """
        for value in self._values[::-1]:
            yield value
