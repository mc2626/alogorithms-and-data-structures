"""
-------------------------------------------------------
Linked versions of various sorts. Implemented on linked Lists.
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
Term:    Winter 2020
__updated__ = "2022-07-27"
-------------------------------------------------------
"""
# pylint: disable=protected-access

# Imports
from math import log
from List_linked import List


class Sorts:
    """
    -------------------------------------------------------
    Defines a number of linked sort operations.
    Uses class attribute 'swaps' to determine how many times 
    elements are swapped by the class.
    Use: print(Sorts.swaps)
    Use: Sorts.swaps = 0
    -------------------------------------------------------
    """
    swaps = 0  # Tracks swaps performed.

    # The Sorts

    @staticmethod
    def selection_sort(a):
        """
        -------------------------------------------------------
        Sorts a linked list using the Selection Sort algorithm.
        Finds maximum value each pass.
        Use: selection_sort(a)
        -------------------------------------------------------
        Parameters:
            a - a linked list of comparable elements (List)
        Returns:
            None
        -------------------------------------------------------
        """
        # Split the list into the sorted (_front) and unsorted parts.
        unsorted = a._front
        a._front = None
        # Go through each node in the unsorted list and find the max value
        # to insert at the front of the sorted list.
        while unsorted is not None:
            max_prev = None
            max_node = unsorted
            previous = unsorted
            current = max_node._next

            while current is not None:
                if current._value > max_node._value:
                    max_prev = previous
                    max_node = current
                previous = current
                current = current._next
            # Remove the max node from the list.
            Sorts.swaps += 1

            if max_prev is None:
                unsorted = max_node._next
            else:
                max_prev._next = max_node._next
            # Move the next max node to the front of the sorted list.
            max_node._next = a._front
            a._front = max_node
        return

    @staticmethod
    def bubble_sort(a):
        """
        -------------------------------------------------------
        Sorts a linked list using the Bubble Sort algorithm.
        Use: bubble_sort(a)
        -------------------------------------------------------
        Parameters:
            a - a linked list of comparable elements (?)
        Returns:
            None
        -------------------------------------------------------
        """
        done = False
        last = None

        while not done:
            # if no elements have been swapped, then the list is sorted
            done = True
            # Get the front of the list.
            previous = None
            current = a._front
            swapped = a._front

            while current is not last and current._next is not None:

                if current._value > current._next._value:
                    # If you swapped you need another pass.
                    done = False
                    # The pair current, current._next is out of order.
                    Sorts.swaps += 1
                    a._swap(previous, current)
                    # Keep track of last node swapped
                    swapped = current
                    # current is unchanged - update previous
                    if previous is None:
                        previous = a._front
                    else:
                        previous = previous._next
                else:
                    # Move to next node.
                    previous = current
                    current = current._next
            last = swapped
        # done == True iff no pair of keys was swapped on the last pass.
        return

    @staticmethod
    def comb_sort(a):
        """
        -------------------------------------------------------
        Sorts an List using the Comb Sort algorithm.
        Use: comb_sort(a)
        -------------------------------------------------------
        Parameters:
          a - a linked list of comparable elements (?)
        Returns:
          None
        -------------------------------------------------------
        """
        n = len(a)

        if n > 0:
            gap = n
            done = False

            while gap > 1 or not done:
                done = True
                previous = None
                current = a._front
                gap = int(gap / 1.3)

                if gap < 1:
                    gap = 1

                i = 0
                prev_far = current
                far = current._next
                # Move to the far node for comparison.
                while i < gap - 1 and far is not None:
                    prev_far = far
                    far = far._next
                    i += 1

                while current is not None and far is not None:
                    if current._value > far._value:
                        Sorts.swaps += 1
                        a._swap(previous, prev_far)
                        done = False
                    # Increment all nodes.
                    prev_far = far
                    far = far._next
                    previous = current
                    current = current._next
        return

    @staticmethod
    def insertion_sort(a):
        """
        -------------------------------------------------------
        Sorts a linked list using the Insertion Sort algorithm.
        Use: insertion_sort(a)
        -------------------------------------------------------
        Parameters:
            a - a linked list of comparable elements (?)
        Returns:
            None
        -------------------------------------------------------
        """
        # Split the list into the sorted (_front) and unsorted parts.
        unsorted = a._front
        a._front = None

        # Go through each node in the unsorted list and insert it into the
        # proper position in the sorted list.
        while unsorted is not None:
            # Isolate the first node of the unsorted list.
            node = unsorted
            unsorted = unsorted._next
            # Find the proper place for the new node in the sorted so far list.
            # (Very similar to priorityQueue insertion.)
            previous = None
            current = a._front

            while current is not None and current._value < node._value:
                previous = current
                current = current._next

            # Insert node into the proper place in the sorted list.
            Sorts.swaps += 1

            if previous is None:
                node._next = a._front
                a._front = node
            else:
                node._next = current
                previous._next = node
        return

    @staticmethod
    def merge_sort(a):
        if a._count >= 2:
            # Split the list only if there are at least two elements.
            # Generate the left and right lists.
            left, right = Sorts._merge_split(a)
            # Sort the left list.
            Sorts.merge_sort(left)
            # Sort the right list.
            Sorts.merge_sort(right)
            # Merge the left and right lists back into a.
            Sorts._merge(a, left, right)
        return

    @staticmethod
    def _merge_split(source):
        # Split the list by count.
        count = source._count // 2
        curr = source._front

        for _ in range(count - 1):
            curr = curr._next

        # Define the left list.
        left = List()
        left._front = source._front
        left._rear = curr
        left._count = count
        # Define the right list.
        right = List()
        right._front = curr._next
        right._rear = source._rear
        right._count = source._count - count
        # Break the link between the two lists.
        left._rear._next = None
        # Empty the source list.
        source.clear()
        return left, right

    @staticmethod
    def _merge(target, left, right):
        # Traverse left and right appending larger value to rear of target.
        while left._front is not None and right._front is not None:

            if left._front._value <= right._front._value:
                target._move_front_to_rear(left)
            else:
                target._move_front_to_rear(right)

        # Append the remaining list - O(1) operation.
        if left._front is not None:
            target._append_list(left)
        elif right._front is not None:
            target._append_list(right)
        return

    @staticmethod
    def quick_sort(a):
        if a._front is not None:
            # Partition the list into three with respect to pivot value.
            lesser, equals, greater = Sorts._partition(a)
            Sorts.quick_sort(lesser)
            Sorts.quick_sort(greater)
            # Put all three lists back together in order.
            if lesser._front is not None:
                a._append_list(lesser)
            a._append_list(equals)
            if greater._front is not None:
                a._append_list(greater)
        return

    @staticmethod
    def _partition(source):
        lesser = List()
        greater = List()
        equals = List()
        pivot = source._front
        # Move this first node to the equals list.
        equals._move_front_to_rear(source)

        while source._front is not None:
            # Process the remaining nodes with respect to the pivot node.
            if pivot._value > source._front._value:
                lesser._move_front_to_rear(source)
            elif pivot._value < source._front._value:
                greater._move_front_to_rear(source)
            else:
                equals._move_front_to_rear(source)
        return lesser, equals, greater

    @staticmethod
    def to_array(a):
        """
        -------------------------------------------------------
        Copies list values to a Python list.
        Use: values = to_array(a)
        -------------------------------------------------------
        Parameters:
            a - a linked list of comparable elements (?)
        Returns:
            returns
            values - the contents of a in a Python list.= (list of ?)
        -------------------------------------------------------
        """
        values = []
        current = a._front

        while current is not None:
            values.append(current._value)
            current = current._next
        return values

    @staticmethod
    def sort_test(a):
        """
        -------------------------------------------------------
        Determines whether a linked list is is_sorted or not.
        Use: Sorts.sort_test(a)
        -------------------------------------------------------
        Parameters:
          a - a linked list of comparable elements (?)
        Returns:
          returns:
          is_sorted - True if contents of a are sorted, False otherwise.
        -------------------------------------------------------
        """
        is_sorted = True
        current = a._front

        while is_sorted and current is not None and \
                current._next is not None:

            if current._value <= current._next._value:
                current = current._next
            else:
                is_sorted = False
        return is_sorted

    @staticmethod
    def sort_test_str(a):
        """
        -------------------------------------------------------
        Determines whether a linked list with strings is
        is_sorted or not.
        Use: Sorts.sort_test_str(a)
        -------------------------------------------------------
        Parameters:
          a - a linked list of comparable elements (?)
        Returns:
          returns:
          is_sorted - True if contents of a are sorted, False otherwise.
        -------------------------------------------------------
        """
        is_sorted = True
        current = a._front

        while is_sorted and current is not None and \
                current._next is not None:

            if current._value.lower() <= current._next._value.lower():
                current = current._next
            else:
                is_sorted = False
        return is_sorted

    @staticmethod
    def radix_sort(a):
        """
        -------------------------------------------------------
        Performs a base 10 radix sort.
        Use: radix_sort(a)
        -------------------------------------------------------
        Parameters:
            a - a List of base 10 integers (List)
        Returns:
            None
        -------------------------------------------------------
        """
        # creates: m_bucket = [[], [], [], [], [], [], [], [], [], []]
        for _ in range(10):
            m_bucket = []
            for _ in range(10):
                b = List()
                m_bucket.insert(0, b)

        if not a.is_empty():
            max_num = a.max()
            length = len(str(max_num))

            for loop in range(length):  # how many times to loop based of max_num

                i = 0  # signifies list position
                while i < len(a):
                    num = a[i]

                    b_index = (num % (10 ** (loop + 1))) // (10 ** loop)
                    bucket = m_bucket[b_index]
                    bucket.append(num)
                    i += 1

                # empty a list and empty out all buckets

                while not a.is_empty():
                    a.pop(0)

                for i in m_bucket:
                    while not i.is_empty():
                        val = i.pop(0)
                        a.append(val)

        return None

    @staticmethod
    def count_sort_letters(array, size, col, base, max_len):
        """ Use in conjuction with radix_sort_string linked version! """

        output = [0] * size
        count = [0] * (base + 1)
        min_base = ord('a') - 1

        for item in array:
            letter = ord(item[col].lower()) - \
                min_base if col < len(item) else 0
            count[letter] += 1

        for i in range(len(count) - 1):
            count[i + 1] += count[i]

        array.reverse()

        for item in array:
            letter = ord(item[col].lower()) - \
                min_base if col < len(item) else 0
            output[count[letter] - 1] = item
            count[letter] -= 1

        return output

    @staticmethod
    def radix_sort_string(strings):
        """
        -------------------------------------------------------
        Sorts a linked list using a radix sort on strings.
        Use: radix_sort_string(a)
        -------------------------------------------------------
        Parameters:
            strings - a list of characters (List)
        Returns:
            None
        -------------------------------------------------------
        """

        max_col = 0
        if not strings.is_empty():
            max_col = len(max(strings, key=len))  # edit to max length

            arr_linked = strings

            # i = max_col - 1
            # while i > -1:
            #     arr_linked = Sorts.count_sort_letters(
            #         arr_linked, len(arr_linked), i, 26, max_col)
            #     i -= 1

            for col in range(max_col - 1, -1, -1):  # max_len-1, max_len-2, ...0
                arr_linked = Sorts.count_sort_letters(
                    arr_linked, len(arr_linked), col, 26, max_col)

            while not strings.is_empty():
                strings.remove_front()

            while len(arr_linked) > 0:
                value = arr_linked.pop(0)
                strings.append(value)

        return None

    @staticmethod
    def bucket_sort(a):
        """
        -------------------------------------------------------
        Sorts an linked list using the Bucket/Bin Sort algorithm.
        Use: Sorts.bucket_sort(a)
        -------------------------------------------------------
        Parameters:
            x - an array of comparable elements (list)
        Returns:
            None
        -------------------------------------------------------
        """
        n = len(a)

        if n > 0 and not Sorts.sort_test(a):
            max_ele = a.max()
            min_ele = a.min()

            # range(for buckets)
            # n = num of buckets
            rnge = (max_ele - min_ele) / n

            temp = []

            # create empty buckets
            for i in range(n):
                temp.append(List())

            # scatter the array elements into the correct bucket
            for i in range(len(a)):
                diff = (a[i] - min_ele) / rnge - int((a[i] - min_ele) / rnge)

                # append the boundary elements to the lower array
                if(diff == 0 and a[i] != min_ele):
                    temp[int((a[i] - min_ele) / rnge) - 1].append(a[i])

                else:
                    temp[int((a[i] - min_ele) / rnge)].append(a[i])

            # Sort each bucket individually
            for i in range(len(temp)):
                if len(temp[i]) != 0:
                    Sorts.insertion_sort(temp[i])

            # Gather sorted elements
            # to the original array
            k = 0
            for lst in temp:
                if lst:
                    for i in lst:
                        a[k] = i
                        k += 1
        return None

    @staticmethod
    def bucket_sort_string(a):
        """
        -------------------------------------------------------
        Sorts an linked list using the Bucket/Bin Sort algorithm.
        Use: Sorts.bucket_sort(a)
        -------------------------------------------------------
        Parameters:
            x - an array of comparable elements (list)
        Returns:
            None
        -------------------------------------------------------
        """
        alpha_dict = {"a": 0, "b": 1, "c": 2, "d": 3, "e": 4, "f": 5, "g": 6, "h": 7, "i": 8, "j": 9, "k": 10, "l": 11, "m": 12,
                      "n": 13, "o": 14, "p": 15, "q": 16, "r": 17, "s": 18, "t": 19, "u": 20, "v": 21, "w": 22, "x": 23, "y": 24, "z": 25}

        m_bucket = []
        for _ in range(26):
            m_bucket.append(List())

        if not a.is_empty():

            # organize bucket contents by first letter of word
            i = 0
            while i < len(a):
                word = a[i]
                if word[0].lower() in alpha_dict.keys():
                    b_index = alpha_dict[word[0].lower()]
                    bucket = m_bucket[b_index]
                    bucket.append(word)
                i += 1

            # sort each bucket separately
            for bucket in m_bucket:
                Sorts.radix_sort_string(bucket)

            # delete old contents in input array: a
            while not a.is_empty():
                a.pop(0)

            # populate input array: a with new sorted contents in each bucket
            for bucket in m_bucket:
                while not bucket.is_empty():
                    val = bucket.pop(0)
                    a.append(val)

        return None
