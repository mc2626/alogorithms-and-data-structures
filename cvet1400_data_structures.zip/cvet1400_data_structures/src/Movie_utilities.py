"""
-------------------------------------------------------
Movie class utility functions.
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-08-18"
-------------------------------------------------------
"""
from Movie import Movie


def get_movie():
    """
    -------------------------------------------------------
    Creates a Movie object by requesting data from a user.
    Use: movie = get_movie()
    -------------------------------------------------------
    Returns:
        movie - a Movie object based upon the user input (Movie).
    -------------------------------------------------------
    """

    title = input("Title: ")
    year = int(input("Year of release: "))
    director = input("Director: ")
    rating = float(input("Rating: "))
    temp_genres = input(
        "\nGenres\n0: science fiction\n1: fantasy\n2: drama\n3: romance\n4: comdey\n5: zombie\n6: action\n7: historicl\n8: horror\n9: war\n10: mystery\nEnter a genre number (ENTER to quit)")

    genres = []
    for ele in temp_genres:
        genres.append(int(ele))

    movie = Movie(title, year, director, rating, genres)

    return movie


def read_movie(line):
    """
    -------------------------------------------------------
    Creates and returns a Movie object from a line of formatted string data.
    Use: movie = read_movie(line)
    -------------------------------------------------------
    Parameters:
        line - a vertical bar-delimited line of movie data in the format
          title|year|director|rating|genre codes (str)
    Returns:
        movie - a Movie object based upon the data from line (Movie)
    -------------------------------------------------------
    """

    data = line.split("|")
    temp = []
    for ele in data[4].split(","):
        temp.append(int(ele))
    movie = Movie(data[0], int(data[1]), data[2], float(data[3]), temp)

    return movie


def read_movies(fv):
    """
    -------------------------------------------------------
    Reads a file of string data into a list of Movie objects.
    Use: movies = read_movies(fv)
    -------------------------------------------------------
    Parameters:
        fv - an already open file of movie data (file)
    Returns:
        movies - a list of Movie objects (list of Movie)
    -------------------------------------------------------
    """

    movies = []
    for line in fv:
        # data = line.split("|")
        # temp = []
        # for ele in data[4].split(","):
        #     temp.append(int(ele))
        # movie = Movie(data[0], int(data[1]), data[2], float(data[3]), temp)
        movie = read_movie(line)
        movies.append(movie)
    return movies


def read_genres():
    """
    -------------------------------------------------------
    Asks a user to select genres from a list of genres and returns
    an integer list of the genres chosen.
    Use: genres = read_genres()
    -------------------------------------------------------
    Returns:
        genres - sorted numeric list of movie genres (list of int)
    -------------------------------------------------------
    """

    # s = Movie.genres_menu()
    # print(s)
    # # temp = []
    # genres = []
    # genre_num = input("Enter a genre number (ENTER to quit)")
    # while genre_num != "":
    #     # if genre is repeated
    #     if not genre_num.isnumeric():
    #         print("Error: not a positive number.")
    #     elif int(genre_num) in genres:
    #         print("Error: genre already chosen")
    #     # if genre number is > 10 or < 10
    #     elif int(genre_num) < 0:
    #         print("Error: not a positive number.")
    #     elif int(genre_num) > 10:
    #         print("Error: input must be <= 10")
    #     else:
    #         genres.append(int(genre_num))
    #
    #     genre_num = input("Enter a genre number (ENTER to quit)")
    #
    # # genres = []
    # # for ele in temp:
    # #     if ele.isnumeric() and int(ele) not in genres and int(ele) >= 0 and int(ele) <= 10:
    # #         genres.append(int(ele))
    #
    # genres.sort()

    ls = []
    ls2 = []
    print(Movie.genres_menu())
    start = True
    while start:
        try:
            a = int(input("Enter a genre number (ENTER to quit): ") or -999)
            if a >= 0 and a <= len(Movie.GENRES) and a not in ls:
                ls.append(a)
            elif a == -999 and len(ls) > 0:
                start = False
            elif a < 0:
                print("Error: not a positive number")
            elif a in ls:
                print("Error: genre already chosen")
            elif a > (len(Movie.GENRES)):
                print("Error: input must be < {0}".format(
                    str(len(Movie.GENRES) - 1)))
        except ValueError:
            print("Error: not a positive number")

    while ls:
        minimum = ls[0]
        for item in ls:
            if item < minimum:
                minimum = item
        ls2.append(minimum)
        ls.remove(minimum)

    genres = ls2
    return genres


def write_movies(fv, movies):
    """
    -------------------------------------------------------
    Writes the contents of movies to fv. Overwrites or
    creates a new file of Movie objects converted to strings.
    Use: write_movies(fv, movies)
    -------------------------------------------------------
    Parameters:
        fv - an already open file of movie data (file)
        movies - a list of Movie objects (list of Movie)
    Returns:
        None
    -------------------------------------------------------
    """

    # Your code here

    return


def get_by_year(movies, year):
    """
    -------------------------------------------------------
    Creates a list of Movies from a particular year.
    The original list of movies must be unchanged.
    Use: ymovies = get_by_year(movies, year)
    -------------------------------------------------------
    Parameters:
        movies - a list of Movie objects (list of Movie)
        year - the Movie year to select (int)
    Returns:
        ymovies - Movie objects whose year attribute is
            year (list of Movie)
    -------------------------------------------------------
    """

    ymovies = []
    for movie in movies:
        if movie.year == year:
            ymovies.append(movie)

    return ymovies


def get_by_rating(movies, rating):
    """
    -------------------------------------------------------
    Creates a list of Movies whose ratings are equal to or higher
    than rating.
    The original list of movies must be unchanged.
    Use: rmovies = get_by_rating(movies, rating)
    -------------------------------------------------------
    Parameters:
        movies - a list of Movie objects (list of Movie)
        rating - the minimum Movie rating to select (float)
    Returns:
        rmovies - Movie objects whose rating attribute is
            greater than or equal to rating (list of Movie)
    -------------------------------------------------------
    """

    rmovies = []
    for movie in movies:
        if movie.rating >= rating:
            rmovies.append(movie)
    return rmovies


def get_by_genre(movies, genre):
    """
    -------------------------------------------------------
    Creates a list of Movies whose list of genres include genre.
    The original list of movies must be unchanged.
    Use: gmovies = get_by_genre(movies, genre)
    -------------------------------------------------------
    Parameters:
        movies - a list of Movie objects (list of Movie)
        genre - the genre code to look for (int)
    Returns:
        gmovies - Movie objects whose genre list includes
            genre (list of Movie)
    -------------------------------------------------------
    """

    gmovies = []

    for movie in movies:
        if genre in movie.genres:
            gmovies.append(movie)
    return gmovies


def get_by_genres(movies, genres):
    """
    -------------------------------------------------------
    Creates a list of Movies whose list of genres include all the genre
    codes in genres.
    The original list of movies must be unchanged.
    Use: m = get_by_genres(movies, genres)
    -------------------------------------------------------
    Parameters:
        movies - a list of Movie objects (list of Movie)
        genres - the genre codes to look for (list of int)
    Returns:
        gmovies - Movie objects whose genre list includes
            all the genres in genres (list of Movie)
    -------------------------------------------------------
    """

    gmovies = []
    movie_index = 0
    match = 0

    # while there is still a list of movie objects to loop through
    while movie_index < len(movies):
        # tracking each movie object
        movie = movies[movie_index]
        for genre in genres:
            if genre in movie.genres:
                match += 1
        if match == len(genres):
            gmovies.append(movie)
        movie_index += 1
        match = 0

    # gmovies = []
    # movie_index = 0
    # match = 0
    #
    # # while there is still a list of movie objects to loop through
    # while movie_index < len(movies):
    #     # tracking each movie object
    #     movie = movies[movie_index]
    #     # looping through genres list
    #     for genre in genres:
    #         # checking to see if the genre is in the movie.genres list within
    #         # the movie objects
    #         if genre in movie.genres:
    #             # if exists, match increase by 1
    #             match += 1
    #     # if the number of matches == the len(genres) and
    #     # number of matches == len(movie.genres)
    #     # it means that we have reached the end of the genres list
    #     # for a particular object
    #     if match == len(genres) and match == len(movie.genres):
    #         # therefore we append that movie object to the gmovies list
    #         # gmovies.append(movie)
    #         gmovies.append(movie)
    #     movie_index += 1
    #     match = 0
    #
    # return gmovies

    return gmovies


def genre_counts(movies):
    """
    -------------------------------------------------------
    Counts the number of movies in each genre given in Movie.GENRES.
    The original list of movies must be unchanged.
    Use: counts = genre_counts(movies)
    -------------------------------------------------------
    Parameters:
        movies - a list of Movie objects (list of Movie)
    Returns:
        counts - the number of Movies in each genre in Movie.GENRES.
            The index of each number in counts is the index of
            the matching genre in Movie.GENRES. (list of int)
    -------------------------------------------------------
    """

    counts = []

    # populate empty count list with zeros as placeholders
    for ele in range(len(Movie.GENRES)):
        counts.append(0)
        ele += 1

    # loop through each movie.genres in each movie object and increase
    # placeholders when a new occurance of a genre appears

    for movie in movies:
        for genre in movie.genres:
            counts[genre] = counts[genre] + 1

    return counts
